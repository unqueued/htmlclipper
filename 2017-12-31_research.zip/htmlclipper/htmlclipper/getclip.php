<?php

file_put_contents("/tmp/". time(), "hi");

if(!empty($_POST)) {
	print "Acknolwedged\n";
	//print_r($_POST);
	file_put_contents("/tmp/". time(), $_POST);
} else {
	print "Nothing submitted";
}

?>